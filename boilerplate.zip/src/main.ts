import gr from "grimoirejs";
export default () => {
  gr.register(async () => {
    /*
    init your plugin here.

    gr.registerNode();
    gr.registerComponent();
     */
  });
};
